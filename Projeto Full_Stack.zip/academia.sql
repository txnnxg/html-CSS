-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03/12/2024 às 03:54
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `academia`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `aluno`
--

CREATE TABLE `aluno` (
  `ID_Aluno` int(11) NOT NULL,
  `Nome_Aluno` varchar(100) NOT NULL,
  `Peso_Aluno` float NOT NULL,
  `Altura_Aluno` float NOT NULL,
  `ID_Professor` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `aluno`
--

INSERT INTO `aluno` (`ID_Aluno`, `Nome_Aluno`, `Peso_Aluno`, `Altura_Aluno`, `ID_Professor`, `email`, `senha`) VALUES
(1, 'Natan', 62.5, 1.69, 1, 'ilunati917@gmail.com', '123'),
(2, 'Joao Pedro', 78.9, 1.68, 1, 'joaopedro@gmail.com', '123'),
(3, 'Felipe M', 86.4, 1.79, 1, 'felipe@gmail.com', '123'),
(4, 'Ruan Guilherme de Almeida', 70, 1.8, 1, 'ruanguilhermedealmeida@gmail.com', '123'),
(5, 'Nicolas Brengadioli', 75.6, 1.82, 2, 'brengadioli@gmail.com', '123');

-- --------------------------------------------------------

--
-- Estrutura para tabela `professor`
--

CREATE TABLE `professor` (
  `ID_Professor` int(11) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Dt_Nasc` date DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `senha` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `professor`
--

INSERT INTO `professor` (`ID_Professor`, `Nome`, `Dt_Nasc`, `email`, `senha`) VALUES
(1, 'Rafael Yogi', '2002-11-04', 'rafaelyogi@gmail.com', '1234'),
(2, 'Rubens', '1979-06-24', 'rubens@gmail.com', '1234'),
(19, '1234', '2001-06-24', 'jeanlondrinet@gmail.com', '');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `aluno`
--
ALTER TABLE `aluno`
  ADD PRIMARY KEY (`ID_Aluno`),
  ADD KEY `FK_ID_Professor` (`ID_Professor`);

--
-- Índices de tabela `professor`
--
ALTER TABLE `professor`
  ADD PRIMARY KEY (`ID_Professor`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `aluno`
--
ALTER TABLE `aluno`
  MODIFY `ID_Aluno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `professor`
--
ALTER TABLE `professor`
  MODIFY `ID_Professor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

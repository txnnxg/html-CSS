<?php
include_once('bancoC.php');
$sql = "SELECT * FROM aluno ORDER BY ID_Aluno DESC";
$sql1 = "SELECT * FROM Professor ORDER BY ID_Professor DESC";

$result = $conexao->query($sql);
$result1 = $conexao->query($sql1);

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Site de banco de dados</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <header id="head"></header>

    <div>
        <table class="table table-dark table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">ID_Aluno</th>
                    <th scope="col">Nome_Aluno</th>
                    <th scope="col">Peso_Aluno</th>
                    <th scope="col">Altura_Aluno</th>
                    <th scope="col">ID_Professor</th>
                    <th scope="col">...</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    while($user_data = mysqli_fetch_assoc($result))
                    {
                        echo "<tr>";
                        echo "<td>".$user_data['ID_Aluno']."</td>";
                        echo "<td>".$user_data['Nome_Aluno']."</td>";
                        echo "<td>".$user_data['Peso_Aluno']."</td>";
                        echo "<td>".$user_data['Altura_Aluno']."</td>";
                        echo "<td>".$user_data['ID_Professor']."</td>";
                        echo "<tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>

    <div>
    <table class="table table-dark table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">ID_Professor</th>
                    <th scope="col">Nome</th>
                    <th scope="col">Dt_Nasc</th>
                    <th scope="col">...</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    while($user_data = mysqli_fetch_assoc($result1))
                    {
                        echo "<tr>";
                        echo "<td>".$user_data['ID_Professor']."</td>";
                        echo "<td>".$user_data['Nome']."</td>";
                        echo "<td>".$user_data['Dt_Nasc']."</td>";
                        echo "<tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>

    <footer></footer>
</body>

</html>
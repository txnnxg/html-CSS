<?php
    if (isset($_POST['submit']) && !empty($_POST['email']) && !empty($_POST['senha'])) {
        include_once('bancoC.php');
        $email = $_POST['email'];
        $senha = $_POST['senha'];


        $sql = "SELECT * FROM professor WHERE email = '$email' AND senha = '$senha'";
        $sql1 = "SELECT * FROM aluno WHERE email = '$email' AND senha = '$senha'";
        $result1 = $conexao->query($sql1);
        $result = $conexao->query($sql);
        if (mysqli_num_rows($result) >= 1) {
            header('Location: chamabanco.php');
        } else {
            if (mysqli_num_rows($result1) >= 1) {
                echo "Área do aluno";
            } else {
                header('Location: tela-de-login.php');
            }
        } 
    }
    else {
        header('Location: tela-de-login.php');
    }
?>
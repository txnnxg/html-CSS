<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="estilos/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <a href="#home"><i class="fas fa-home"></i><span>Home</span></a>
            <a href="#about"><i class="fas fa-user"></i><span>login</span></a>
            <a href="#contact"><i class="fas fa-contact-card"></i><span>Register</span></a>
        </nav>
    </header>

    <div class="container">
        <section id="home" class="home">academia popular fit</section>
        <section id="about" class="about"><a href="http://localhost/full_stack/tela-de-login.php" style="text-decoration: none; color:aliceblue">Login</a></section>
        <section id="contact" class="contact">Register</section>
    </div>
</body>
</html>